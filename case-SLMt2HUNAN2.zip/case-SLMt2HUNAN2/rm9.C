#include <stdio.h>

int main()
{
    FILE *fileptr1, *fileptr2;
    char ch;
    int  temp = 0;
    fileptr1 = fopen("dump160000.nozzel", "r");
    
    ch = 'A';

/*int tline=1;
      while ((ch = getc(fileptr1)) != EOF)
    {
       
        if (ch == '\n')
        {
            tline++;
        }   
       else
        { ch=fgetc(fileptr1);
          if(ch==EOF){tline++;break;}
        }  
    }
printf("%d",tline);
rewind(fileptr1);*/
fileptr2 = fopen("dump.txt", "w");
ch = 'A';int nc=1;
 while ( temp<=100000)
    {   
        ch = getc(fileptr1);
        nc++;
        if(nc>=100) break;
        //except the line to be deleted
        if (temp >=9)
        {
            //copy all lines in file replica.c
            putc(ch, fileptr2);
        }
        if (ch == '\n')
        {
            temp++;nc=0;
        }
       
    }
    
    fclose(fileptr1);
    fclose(fileptr2);
    
}
