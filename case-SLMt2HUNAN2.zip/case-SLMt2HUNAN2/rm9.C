#include <stdio.h>

int main()
{
    FILE *fileptr1, *fileptr2;
    char ch;
    int  temp = 0; int tt=0;
    fileptr1 = fopen("dump0.txt", "r");
    
    ch = 'A';
    int nc=1;
 while ( temp<=200000)
    {   
        ch = getc(fileptr1);
        nc++;
        if(nc>=100) break;
   
        
        if (ch == '\n')
        {
            temp++;nc=0;
        }
       
    }
    tt=temp;
    printf("%d",tt);
/*
int tline=1;
      while ((ch = getc(fileptr1)) != EOF)
    {
       
        if (ch == '\n')
        {
            tline++;
        }   
       else
        { ch=fgetc(fileptr1);
          if(ch==EOF){tline++;break;}
        }  
    }
printf("%d",tline);
rewind(fileptr1);*/
fclose(fileptr1);
fileptr1 = fopen("dump0.txt", "r");
fileptr2 = fopen("dump.txt", "w");
ch = 'A';int ncc=1; temp=0;
 while ( temp<=200000)
    {   
        ch = getc(fileptr1);
        ncc++;
        if(ncc>=100) break;
        //except the line to be deleted
        if (temp >=18 && temp < tt)
        {
            //copy all lines in file replica.c
            putc(ch, fileptr2);
        }
        if (ch == '\n')
        {
            temp++;ncc=0;
        }
       
    }
    
    fclose(fileptr1);
    fclose(fileptr2);
   
    
}
