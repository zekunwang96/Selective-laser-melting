#include"stdio.h"
int main()
{
FILE *fp;FILE *fp2;
fp=fopen("dump.txt","r");
fp2=fopen("funkySetFieldsDict","w");
double x=0; double y=0;double z=0;double R=0;
int n=1;int N=1; 
char*A="pow(pow(pos().x-"; char*B=",2)+pow(pos().y-";
char*C=",2)+pow(pos().z-"; char*D=",2),0.5)<="; char*E="||";
char*B1="alpha";char*B2="{field alpha.phase1;expression\"1\";condition \"";
char*End1="\";keepPatches true;}";
char*End2="pos().z<=0\";keepPatches true;});";
char*B01="FoamFile{version     2.0;format      ascii;class       dictionary;location    \"system\";object      funkySetFieldsDict;}expressions";
char*B02="(";
int total=0; int Num=0;
if(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{while(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4) total++;}
fclose(fp);
fp=fopen("dump.txt","r");
if(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{
fprintf(fp2,"%s\n%s",B01,B02);
while(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{ if(n==1){fprintf(fp2,"%s%d%s%s%f%s%f%s%f%s%f%s",B1,N,B2,A,x,B,y,C,z,D,R,E);
n++;Num++;
} 
else if(n<9){
fprintf(fp2,"%s%f%s%f%s%f%s%f%s",A,x,B,y,C,z,D,R,E);
n++;Num++;}
else if(n==9 && Num!=total-1) {
fprintf(fp2,"%s%f%s%f%s%f%s%f%s\n\n",A,x,B,y,C,z,D,R,End1);
n=1;N++;Num++;} 
else if(n==9 && Num==total-1) {
fprintf(fp2,"%s%f%s%f%s%f%s%f%s",A,x,B,y,C,z,D,R,E);
} 
}
fprintf(fp2,"%s\n",End2);
}
fclose(fp);fclose(fp2);
}

