#source 2020.11/profile.d/use_cfdem.env # CFDEM environment
cd DEM    # DEM only
./lmp_auto<in0.liggghts_run
cd ..
./rm9.out
cp -r backupfields/alpha* 0/
cp -r backupfields/h 0/
./setalpha1.out
setFields
./seth.out
setFields 
rm -r pro*
decomposePar
source 2020.11/profile.d/use_openfoam3.0.1.env   #OpenFOAM env
mpirun -n N SLMv5 -parallel # N is number of processors
./depth.out

