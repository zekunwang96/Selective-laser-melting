#include"stdio.h"


int main()
{
FILE *fp;FILE *fp2;
fp=fopen("dump.txt","r");
fp2=fopen("system/setFieldsDict","w");
double x=0; double y=0;double z=0;double R=0;
int n=1;int N=1; 
char*A=" sphereToCell { centre  ("; char*B=");        radius  ";
char*End1=";        fieldValues (            volScalarFieldValue alpha.phase1 1                );    }";
char*End2="; fieldValues        (            volScalarFieldValue alpha.phase1 1                );   });";
char*B01="FoamFile {version     2.0;format      ascii;class       dictionary; object      setFieldsDict;} defaultFieldValues     (    volScalarFieldValue alpha.phase1 0 ); regions ( boxToCell    {       box (0 0.00001 -0.000235) (0.001 0.00029 0);        fieldValues        (           volScalarFieldValue alpha.phase1 1        );    }";
char*B02=" ";char*B03=");";
int total=1; int Num=1;
if(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{while(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4) total++;}
fclose(fp);
printf("%d%s",total,"T");

fp=fopen("dump.txt","r");
if(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{
fprintf(fp2,"%s\n%s",B01,B02);
while(fscanf(fp,"%lf	%lf	%lf	%lf",&x,&y,&z,&R)==4)
{  
printf("%d%s",Num,"A");
if(Num < total)
{
fprintf(fp2,"%s%f%s%f%s%f%s%f%s",A,x,B02,y,B02,z,B,R,End1);printf("%d%s",Num,"B"); 
Num++;
} 


}
fprintf(fp2,"%s",B03);
}
fclose(fp);fclose(fp2);
}

