
#include"stdio.h"
int main()
{

FILE *fp;FILE *fp2;
fp=fopen("depth/depth.txt","r");
fp2=fopen("depth/depth2.txt","w");
double zmin=1e3; double xmin=0;double z0=0;double x0=0;
int n=1;int Nproc=2;
while(fscanf(fp,"%lf	%lf",&z0,&x0)==2)
{  if(n<Nproc){if(z0<=zmin){zmin=z0;xmin=x0;}z0=0;n++;}
    else if(n==Nproc) {if(z0<=zmin){zmin=z0;xmin=x0;}z0=0;fprintf(fp2,"%f %f\n",zmin,xmin);zmin=1e3;n=1;} 
}

fclose(fp);fclose(fp2);
}
//gcc recon.C  to compile
