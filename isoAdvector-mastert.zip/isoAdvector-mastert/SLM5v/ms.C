/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011-2015 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    interDyMFoam

Description
    Solver for 2 incompressible, isothermal immiscible fluids using a VOF
    (volume of fluid) phase-fraction based interface capturing approach,
    with optional mesh motion and mesh topology changes including adaptive
    re-meshing.

\*---------------------------------------------------------------------------*/
#include "isoAdvection.H"
#include "fvCFD.H"
//#include "dynamicFvMesh.H"
#include "CMULES.H"
#include "EulerDdtScheme.H"
#include "localEulerDdtScheme.H"
#include "CrankNicolsonDdtScheme.H"
#include "subCycle.H"
#include "immiscibleIncompressibleTwoPhaseMixture.H"
#include "turbulentTransportModel.H"
#include "pimpleControl.H"
#include "fvIOoptionList.H"
#include "CorrectPhi.H"
#include "fixedFluxPressureFvPatchScalarField.H"
#include "localEulerDdtScheme.H"
#include "fvcSmooth.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createMesh.H"
   // #include "createDynamicFvMesh.H"
    #include "initContinuityErrs.H"

    pimpleControl pimple(mesh);

    #include "createControls.H"
    #include "createRDeltaT.H"
    #include "createFields.H"
    #include "createMRF.H"
    #include "createFvOptions.H"

    volScalarField rAU
    (
        IOobject
        (
            "rAU",
            runTime.timeName(),
            mesh,
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE
        ),
        mesh,
        dimensionedScalar("rAUf", dimTime/rho.dimensions(), 1.0)
    );

    #include "correctPhi.H"
    //#include "createUf.H"

    if (!LTS)
    {
        #include "CourantNo.H"
        #include "setInitialDeltaT.H"
    }

    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
    Info<< "\nStarting time loop\n" << endl;
    FILE *fp;FILE *fp1;
    fp=fopen("depth/depth.txt","w");
    fprintf(fp,"%f	%f\n",0.0,0.0);
     fprintf(fp,"%f	%f\n",0.0,0.0);
     fclose(fp);
 int  nump=points.size();
         double laserx[nump];     double lasery[nump];   double laserz[nump]; double laserl[nump-1];
         vector po=vector(0,0,0); double laserT[nump-1]; double laserTi[nump]; laserTi[0]=0;
         for (int i=0; i<nump;i++)
         {   vector po=points[i];
             laserx[i]=po.component(0); lasery[i]=po.component(1); laserz[i]=po.component(2);
         };
         for (int I=0; I<nump-1;I++)
         {   laserl[I]=mag(points[I+1]-points[I]);laserT[I]=laserl[I]/vxl.value(); };
         for (int N=1; N<nump;N++)
         {   laserTi[N]=laserTi[N-1]+laserT[N-1];};


         dimensionedScalar lx=s1;  dimensionedScalar ly=s1;

    while (runTime.run())
    {
        #include "readControls.H"

        if (LTS)
        {
            #include "setRDeltaT.H"
        }
        else
        {
            #include "CourantNo.H"
            #include "alphaCourantNo.H"
            #include "setDeltaT.H"
        }

        runTime++;

        
  Info<< "Time = " << runTime.timeName() << nl << endl;
/////////////////////////////////
      for (int nn=0; nn<nump-1;nn++)
     { if(laserTi[nn]<=runTime.value() && laserTi[nn+1]>runTime.value())
         {lx=s1*(laserx[nn]+(laserx[nn+1]-laserx[nn])*(runTime.value()-laserTi[nn])/laserT[nn]);      
          ly=s1*(lasery[nn]+(lasery[nn+1]-lasery[nn])*(runTime.value()-laserTi[nn])/laserT[nn]);  }
                                  };



        // --- Pressure-velocity PIMPLE corrector loop
        while (pimple.loop())
        {
          
            #include "alphaControls.H"
      
            #include "advectInterface.H"

            mixture.correct();

            muw=pos(Tli-T/T1)*m1*exp(-C1*erf((4.0/(log(Tli)-log(Tso)))*(log(T/T1)-0.5*(log(Tso)+log(Tli))))+C1+log(muli))+pos(T/T1-Tli)*muli*m1*sqrt(Tli*T1/T)*exp(B*(Tli*T1/T-1.0)); 
            mmu=alpha1*muw+(1-alpha1)*mua;
           
            muwafa=alpha1*0.5*(1+tanh(4*(T/T1-0.5*Tso-0.5*Tli)/(Tli-Tso)));
            vafa=alpha1*0.5*(1+tanh(4*(T/T1-Tv/T1)/(Tli-Tso)));

            Cpw=(Cs0+Cs1*T+Cs2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(Cl0+Cl1*T+Cl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0);
            kw=(ks0+ks1*T+ks2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(kl0+kl1*T+kl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0);
            DC= Dc*pow(1.0-muwafa,2)/(pow(muwafa,3)+Dcs);
            Cp=alpha1*Cpw+(1.0-alpha1)*Cpa;
            kk=alpha1*kw+(1.0-alpha1)*ka;

            gradalpha1=fvc::grad(alpha1);
            n=-gradalpha1/(10/s1+mag(gradalpha1)); n=n/(1e-5+mag(n));
            //h=Cp*T;       
        
            #include "UEqn.H"

            Time=tt1*runTime.value();


            hswap=(h*0.5*(1.0-tanh(0.01*(h-Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv))/(Cp1*T1)))+Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv)*0.5*(1.0+tanh(0.01*(h-Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv))/(Cp1*T1))))*alpha1+(1-alpha1)*(h*0.5*(1.0-tanh(0.01*(h-Tc*(Cp1*1007))/(Cp1*T1)))+Tv*(Cpa)*0.5*(1.0+tanh(0.01*(h-Tc*(Cp1*1007))/(Cp1*T1))));
            h=hswap;
H=2.0*Rl*0.816*1.37*Hc*beta*Pl/(Rl*(Tv-Tref+(LL+lv)/(Cl0+Cl1*T1*Tli+Cl2*Tli*Tli*T1*T1))*sqrt(3.1415926*Rl*vxl*(kl0+kl1*Tli*T1+kl2*Tli*Tli*T1*T1)*(Cl0+Cl1*Tli*T1+Cl2*Tli*Tli*T1*T1)*rho1));
W=2.0*Rl*sqrt(log(H/(2.0*Rl)));
//            H=1.37*0.816*Hc*beta*Pl*sqrt(runTime.time())/(Rl*Rl*(Tv-Tref+(LL+lv)/Cl0)*sqrt(3.1415926*kl0*Cl0*rho1));

            #include "TEqn.H"

            // --- Pressure corrector loop
            while (pimple.correct())
            {
                #include "pEqn.H"
            }

            if (pimple.turbCorr())
            {
                turbulence->correct();
            }
            }

         hswap=(h*0.5*(1.0-tanh(0.01*(h-Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv))/(Cp1*T1)))+Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv)*0.5*(1.0+tanh(0.01*(h-Tv*(Cl0+Cl1*Tv+Cl2*Tv*Tv))/(Cp1*T1))))*alpha1+(1-alpha1)*(h*0.5*(1.0-tanh(0.01*(h-Tc*(Cp1*1007))/(Cp1*T1)))+Tv*(Cpa)*0.5*(1.0+tanh(0.01*(h-Tc*(Cp1*1007))/(Cp1*T1))));
           h=hswap;

            T=h/Cp;//alpha1*h/Cpw+(1-alpha1)*h/Cpa;
            muw=pos(Tli-T/T1)*m1*exp(-C1*erf((4.0/(log(Tli)-log(Tso)))*(log(T/T1)-0.5*(log(Tso)+log(Tli))))+C1+log(muli))+pos(T/T1-Tli)*muli*m1*sqrt(Tli*T1/T)*exp(B*(Tli*T1/T-1.0));
            mmu=alpha1*muw+(1-alpha1)*mua;
            muwafa=alpha1*0.5*(1+tanh(4*(T/T1-0.5*Tso-0.5*Tli)/(Tli-Tso)));
            vafa=alpha1*0.5*(1+tanh(4*(T/T1-Tv/T1)/(Tli-Tso)));

            Cpw=(Cs0+Cs1*T+Cs2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(Cl0+Cl1*T+Cl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0);
            kw=(ks0+ks1*T+ks2*T*T)*0.5*(1.0-erf(4*(T/T1-Tli)/(Tli-Tso)))+(kl0+kl1*T+kl2*T*T)*0.5*(erf(4*(T/T1-Tli)/(Tli-Tso))+1.0);
            Cp=alpha1*Cpw+(1.0-alpha1)*Cpa;
            kk=alpha1*kw+(1.0-alpha1)*ka;

            DC= Dc*pow(1.0-muwafa,2)/(pow(muwafa,3)+Dcs);

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
  ////////////////////////////////////////
        float z0=0.0; float zmin=0.0;float dis=0.0;float dis2=0.0;float xmin=0.0;     

        forAll(T,celli)
        {  dis=mesh.C()[celli].component(0)-(lx.value()-0.5*Rl.value());//
           dis2=mesh.C()[celli].component(0)-(lx.value()-1.5*Rl.value());//

           if(dis<=0.0 && dis2>=0.0)
               { 
               float TT;  TT=scalar(T[celli]);
               if(TT>=Tso.value())
                    {  z0=mesh.C()[celli].component(2);
                    if(z0<=zmin) {zmin=z0;xmin=mesh.C()[celli].component(0);}
                    } 
               }
        }
        zmin=1e6*zmin;xmin=1e6*xmin;
        fp=fopen("depth/depth.txt","a+");
        fprintf(fp,"%f	%f\n",zmin,xmin);
        fclose(fp);
        Info<<"zmin="<<zmin<<endl;
//////////////////////////////////////
    }

    
    Info<< "End\n" << endl;
    return 0;
}


// ************************************************************************* //
